
<div style="text-align: center">
    <span style="font-size: 3em; font-weight: 700; font-family: Consolas">
        Lab 01 <br>
        A Gentle Introduction to Hadoop
    </span>
    <br><br>
    <span style="">
        A assignment for <code>CSC14118</code> Introduction to Big Data @ 20KHMT1
    </span>
    <br><br>
</div>

## Collaborators (All in)

- `20120011` **Nguyễn Hoàng Huy**
- `20120030` **Nguyễn Thiên An**
- `20120090` **Nguyễn Thế Hoàng**
- `20120165` **Hồng Nhất Phương**

## Instructors

- `HCMUS` **Nguyễn Ngọc Thảo** ([@nnthao](nnthao@fit.hcmus.edu.vn))
- `HCMUS` **Đoàn Đình Toàn** ([@ddtoan](ddtoan18@clc.fitus.edu.vn))

## Extra



---
<div style="page-break-after: always"></div>
