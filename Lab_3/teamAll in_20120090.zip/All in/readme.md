# Lab 03 - Apache Spark with MongoDB

## Overview
- Course: Introduction to Big Data
- Instructors: 
1. `HCMUS` **Nguyễn Ngọc Thảo** ([@nnthao](nnthao@fit.hcmus.edu.vn))
1. `HCMUS` **Đoàn Đình Toàn** ([@ddtoan](ddtoan18@clc.fitus.edu.vn))
- Lab 03: Apache Spark with MongoDB

## Collaborators (All in)

- `20120011` **Nguyễn Hoàng Huy**
- `20120030` **Nguyễn Thiên An**
- `20120090` **Nguyễn Thế Hoàng**
- `20120165` **Hồng Nhất Phương**

## Note

- [Google Colab source codes](https://colab.research.google.com/drive/1atbWq8fCiNAnaavg_76sqWeRwpzgnlJU)

---
<div style="page-break-after: always"></div>